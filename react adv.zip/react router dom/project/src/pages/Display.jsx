import axios from "axios";
import { useEffect } from "react";
import { useState } from "react";
const Display=()=>{
    const [mydata,setMydata]=useState([]);
    const loadData=()=>{
        let api="http://localhost:3000/Student";
        axios.get(api).then((res)=>{
            console.log(res.data);
            setMydata(res.data);
        }).catch((err)=>{
            console.log(err);
        });
    }
    useEffect(()=>{
        loadData();    
    },[]);
    const ans = mydata.map((key)=>{
        return(
            <>
            <tr>
                <td>{key.rollno}</td>
                <td>{key.name}</td>
                <td>{key.city}</td>
                <td>{key.fees}</td>
            </tr>
            </>
        )
    });
    return(
        <>
        <h1>Display Data</h1>
        <table width="400" border="1" bgcolor="ywllow">
            <tr bgcolor="orange">
                <th>Roll no </th>
                <th>Name</th>
                <th>City</th>
                <th>Fees</th>
            </tr>
            {ans}
        </table>
        </>
    )
}
export default Display;