import { useState } from "react";
import axios from "axios";

const Insert=()=>{
    const[input,setInput] = useState({});
    const handleInput=(e)=>{
        let name = e.target.name;
        let value = e.target.value;
        setInput(values=>({...values,[name]:value}));
        console.log(input);
    }
    const handleSubmit=()=>{
        let api = "http://localhost:3000/Student";

        axios.post(api,input).then((res)=>{
            alert("Data Save!!!");
        })
    }
    return(
        <>
        <h1>Insert data</h1>
        Enter Rollno :<input type="text" name="rollno" onChange={handleInput}/>
        <br />
        Enter Rollno :<input type="text" name="rollno" onChange={handleInput}/>
        <br />
        Enter Rollno :<input type="text" name="rollno" onChange={handleInput}/>
        <br />
        Enter Rollno :<input type="text" name="rollno" onChange={handleInput}/>
        <br />
        <button onClick={handleInput}>Data Save</button>
        </>
    )
}
export default Insert;